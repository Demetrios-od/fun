var titl = {
  ru: 'Исследование радиоканала',
  en: 'Researching a radio link',
  ua: 'Дослідження радіоканала'
};

var titl = {
  ru: 'Исследование приёмопередатчика GSM',
  en: 'Researching a GSM Transceiver',
  ua: 'Дослідження прийомопередавача GSM'
};
